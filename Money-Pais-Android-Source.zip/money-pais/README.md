# Money Pais — Android personal finance tracker

Money Pais is a blue minimalist Indonesian Rupiah expense tracker. It includes income/expense entry, categories, six-month chart, savings goal, XLSX/PDF export, local persistence, and optional Firebase email/password + Firestore cloud sync.

## Important status
- The app works locally immediately in a browser/WebView.
- Cloud sync is **not active until you add your own Firebase project configuration** to `www/app.js` and publish Firestore security rules.
- This source bundle is not a compiled APK. Build the APK using the steps below.

## 1. Configure Firebase cloud sync
1. Open https://console.firebase.google.com/ and create a project named `Money Pais`.
2. Add a Web app in Project settings and copy its Firebase config.
3. In Firebase Authentication → Sign-in method, enable **Email/Password**.
4. Create a Cloud Firestore database.
5. Replace the empty values in `FIREBASE_CONFIG` at the top of `www/app.js` with your project's values.
6. In Firestore Rules, publish:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Do not use open rules such as `allow read, write: if true`.

## 2. Build Android APK
Requirements: Node.js LTS, Android Studio, Android SDK, and a JDK supported by your installed Android Gradle Plugin.

From this folder run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows the output path, normally `android/app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build → Generate Signed Bundle / APK → APK**, create and safely store your signing key, then finish the wizard. Do not share the keystore or its password.

## 3. Install on your Android phone
Transfer the generated APK to your phone, open it, and allow installation from that source if Android asks. For updates, keep the same signing key.

## Notes
- Local records are stored in this app's WebView local storage. Uninstalling/clearing app data can remove local-only records.
- When Firebase is configured, sign in on the device to load and sync records. For production use, consider adding conflict resolution, scheduled backups, and stronger validation.
- XLSX/PDF export libraries and Firebase SDK are loaded from their official/public CDN URLs, so those features need internet access.

## Alternative: build APK online without Android Studio
This project includes `.github/workflows/build-apk.yml` for GitHub Actions. Upload the extracted project to a GitHub repository, open the **Actions** tab, select **Build Money Pais APK**, choose **Run workflow**, and wait for the run to finish. Download the `money-pais-debug-apk` artifact from that run; it contains `app-debug.apk`. You still need a browser/GitHub account, and Firebase configuration must be added before building if you want cloud sync enabled in that APK.
